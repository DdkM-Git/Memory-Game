import { Box } from '@mui/material';
import PanelCard from './PanelCard';

function Panel() {
    return (<Box sx={{ width: "80%", }}>
        <Box sx={{
            width: "660px",
            height: "660px",
            background: "#A99",
            display: "grid",
            gridTemplate: "repeat(3, 200px) / repeat(3, 200px);",
            rowGap: "20px",
            columnGap: "20px",
            paddingTop: "20px",
            paddingLeft: "20px"
        }}>
            <PanelCard></PanelCard>
            <PanelCard></PanelCard>
            <PanelCard></PanelCard>
            <PanelCard></PanelCard>
            <PanelCard></PanelCard>
            <PanelCard></PanelCard>
            <PanelCard></PanelCard>
            <PanelCard></PanelCard>
            <PanelCard></PanelCard>
        </Box>   </Box>
    );
}

export default Panel;
